﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Secure_Profile1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtfname.Text = Profile.fname;
        txtlname.Text = Profile.lname;
        Response.Write("<body bgcolor="+System.Drawing.Color.FromName(Profile.fcolor)+">");
        txtbd.Text = Profile.bd;
        Image1.ImageUrl = "~/" + Profile.profpic;
    }
}
