﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class About : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie obj1 = Request.Cookies["itemdetails"];
        if (obj1 != null) 
        {
            txtno.Text = obj1.Values["itemno"];
            txtname.Text = obj1.Values["itemname"];
            txtqty.Text = obj1.Values["itemqty"];
            txtpr.Text = obj1.Values["itemprice"];
        }
        
       /*Response.Write(Request.QueryString["no"].ToString());
       Response.Write(Request.QueryString["name"].ToString());*/

      /* Response.Write(Session["price"].ToString());
       Response.Write(Session["qty"].ToString()); */
    }
}
