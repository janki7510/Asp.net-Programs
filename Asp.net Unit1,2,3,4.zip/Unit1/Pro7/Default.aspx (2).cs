﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnQuary_Click(object sender, EventArgs e)
    {
       // Response.Redirect("About.aspx ? no=" + txtNo.Text + "&name=" + txtName.Text);
    }
    protected void Btnsession_Click(object sender, EventArgs e)
    {
        /*Session["price"] = txtPrice.Text;
        Session["qty"] = txtQty.Text;
        Response.Redirect("About.aspx");*/
    }
    protected void btnCookie_Click(object sender, EventArgs e)
    {
        HttpCookie obj1 = new HttpCookie("itemdetails");
        obj1.Values["itemno"] = txtNo.Text;
        obj1.Values["itemname"] = txtName.Text;
        obj1.Values["itemqty"] = txtQty.Text;
        obj1.Values["itemprice"] = txtPrice.Text;
        obj1.Expires.AddMinutes(1);
        Response.Cookies.Add(obj1);
        Response.Redirect("About.aspx");
   }
}
