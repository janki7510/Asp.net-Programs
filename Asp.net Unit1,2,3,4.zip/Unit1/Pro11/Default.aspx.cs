﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;   
    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton1.Checked == true)
        {
            Panel1.Visible = true;
            Panel2.Visible = false;
            Panel3.Visible = false;
        }
    }
    protected void RadioButton2_CheckedChanged1(object sender, EventArgs e)
    {
        if (RadioButton2.Checked == true)
        {
            Panel1.Visible = false;
            Panel2.Visible = true;
            Panel3.Visible = false;
        }
    }
    protected void RadioButton3_CheckedChanged1(object sender, EventArgs e)
    {
        if (RadioButton3.Checked == true)
        {
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = true;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //Response.Redirect("cashdetails.aspx?cash=" + TextBox1.Text);
        Session["cash"] = TextBox1.Text;
        Response.Redirect("cashdetails.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("creditdetails.aspx?cardno=" + TextBox2.Text + "&cardname=" + TextBox3.Text + "&expmon=" + TextBox4.Text + "&cardamt=" + TextBox5.Text);
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
       // Response.Redirect("chequedetails.aspx?chequeno=" + TextBox6.Text + "&chequedate=" + TextBox7.Text + "&chequeamt=" + TextBox8.Text + "&date" + TextBox9.Text);
        HttpCookie obj = new HttpCookie("Payment");
        obj.Values["chequeno"] = TextBox6.Text;
        obj.Values["chequedate"] = TextBox7.Text;
        obj.Values["chequeamt"] = TextBox8.Text;
        obj.Values["date"] = TextBox9.Text;
        Response.Cookies.Add(obj);
        Response.Redirect("chequedetails.aspx");

    }

    
}
