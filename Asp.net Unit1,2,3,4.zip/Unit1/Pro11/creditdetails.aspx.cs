﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class creditdetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label6.Text = Request.QueryString["cardno"];
        Label7.Text = Request.QueryString["cardname"];
        Label8.Text = Request.QueryString["expmon"];
        Label9.Text = Request.QueryString["cardamt"];

    }
}
