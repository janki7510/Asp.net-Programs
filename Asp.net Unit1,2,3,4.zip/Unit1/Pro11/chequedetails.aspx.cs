﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class chequedetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        /*Label10.Text = Request.QueryString["chequeno"];
        Label11.Text = Request.QueryString["chequedate"];
        Label12.Text = Request.QueryString["chequeamt"];
        Label13.Text = Request.QueryString["date"];*/
        HttpCookie obj = Request.Cookies["Payment"];
        if (obj != null)
        {
        
        Label10.Text = obj.Values["chequeno"].ToString();
        Label11.Text = obj.Values["chequedate"].ToString();
        Label12.Text = obj.Values["chequeamt"].ToString();
        Label13.Text = obj.Values["date"].ToString();
        }
    }
}
