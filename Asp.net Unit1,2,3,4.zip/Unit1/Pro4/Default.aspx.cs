﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Calculator;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Btnadd_Click(object sender, EventArgs e)
    {
       // Calculator.SimpleArith obj = new Calculator.SimpleArith();
        SimpleArith obj = new SimpleArith();
        int a=Convert.ToInt32(txtno1.Text);
        int b=Convert.ToInt32(txtno2.Text);
        Lblout.Text = "Sum of " + a + " and " + b + " is:" + obj.sum(a, b).ToString();
    }
    protected void BtnSub_Click(object sender, EventArgs e)
    {
        Calculator.SimpleArith obj = new Calculator.SimpleArith();
        int a=Convert.ToInt32(txtno1.Text);
        int b=Convert.ToInt32(txtno2.Text);
        Lblout.Text = "Subtraction of " + a + " and " + b + " is:" + obj.sub(a, b).ToString();
    }
    protected void  BtnMul_Click(object sender, EventArgs e)
    {
        Calculator.AdvArith obj = new Calculator.AdvArith();
        int a=Convert.ToInt32(txtno1.Text);
        int b=Convert.ToInt32(txtno2.Text);
        Lblout.Text = "Multiplication of " + a + " and " + b + " is:" + obj.mul(a, b).ToString();
    }
   protected void  BtnDiv_Click(object sender, EventArgs e)
   {
        Calculator.AdvArith obj = new Calculator.AdvArith();
        int a=Convert.ToInt32(txtno1.Text);
        int b=Convert.ToInt32(txtno2.Text);
        Lblout.Text = "Division of " + a + " and " + b + " is:" + obj.div(a, b).ToString();
    }
}



