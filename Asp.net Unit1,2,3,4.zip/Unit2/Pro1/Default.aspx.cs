﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        lblcost.Text = "cost of selected product " + DropDownList1.SelectedItem.Text + " is Rs. " + DropDownList1.SelectedValue;
    }
    protected void BtnTotal_Click(object sender, EventArgs e)
    {
        int cost=Convert.ToInt32(DropDownList1.SelectedValue);
        int qty=Convert.ToInt32(TextBox1.Text);
        Labtotal.Text = (qty * cost).ToString();
    }
}
