﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page 
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\Asp Programs\Unit2\Pro5\App_Data\StateCity.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand("select StateName from State",con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            DropDownState.Items.Add(Convert.ToString(dr[0]));
        }
        con.Close();
    }
    protected void DropDownState_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownCity.Items.Clear();
        con.Open();
        cmd = new SqlCommand("select CityName from City where StateId=(select StateId from State where StateName='"+DropDownState.Text+"')",con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
           DropDownCity.Items.Add(Convert.ToString(dr[0]));
           DropDownState.Items.Clear();
        }
        con.Close();
    }
}
