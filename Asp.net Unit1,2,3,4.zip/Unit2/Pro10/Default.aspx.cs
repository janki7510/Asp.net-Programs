﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\Asp Programs\Unit2\Pro10\App_Data\FriendsData.mdf;Integrated Security=True;User Instance=True");
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from FriendDetails",con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            DateTime dt = (DateTime)dr.GetValue(2);
            DateTime dt1 = e.Day.Date;
            if (dt.Month == dt1.Month)
            {
                if (Convert.ToString(dt.Day) == e.Day.DayNumberText)
                {
                    LiteralControl l1 = new LiteralControl();
                    l1.Text = "<br/>Birthday";
                    e.Cell.Controls.Add(l1);
                    /*int n = Convert.ToInt32(dr.GetValue(0));
                    LiteralControl l1 = new LiteralControl("<br/><a href=Default2.aspx?EventId="+n+">Birthday</a>");
                    e.Cell.Controls.Add(l1);*/
                }
            }
        }
    }
}
