﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DirectoryInfo d1=new DirectoryInfo(Server.MapPath("~/images/"));
        FileInfo[] f1 = d1.GetFiles();
        DataList1.DataSource = f1;
        DataList1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile == true)
        {
            string ext = Path.GetExtension(FileUpload1.FileName);
            if (ext.ToLower() == ".jpg" || ext.ToLower() == ".jpeg")
            {
                if (FileUpload1.PostedFile.ContentLength <= 100000)
                {
                    FileUpload1.SaveAs(Server.MapPath("~/images/") + FileUpload1.PostedFile.FileName);
                    Response.Write("File is Selected <br>");
                    Response.Write(FileUpload1.FileName + "<br>");
                    Response.Write("<br>" + FileUpload1.PostedFile.FileName + "<br>");
                    Response.Write(FileUpload1.PostedFile.ContentLength + "<br>");
                    Response.Write(FileUpload1.PostedFile.ContentType + "<br>");

                }
                else
                {
                    Response.Write("<script>alert('file size should be <= 10000')</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('select only .jpg or .jpeg file')</script>");
            }
           
           // FileUpload1.SaveAs(Server.MapPath("~/images/") + FileUpload1.FileName);
        }
        else
        {
            Response.Write("<script>alert('select file')</script>");
        }
    }

    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
