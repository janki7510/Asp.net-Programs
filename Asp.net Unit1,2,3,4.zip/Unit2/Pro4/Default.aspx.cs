﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie obj1 = Request.Cookies["u2p4"];
        if (obj1 == null)
        {
            obj1 = new HttpCookie("u2p4");
            obj1.Values["count1"] = "1";
        }
        else
        {
            obj1.Values["count1"] = (Convert.ToInt32(obj1.Values["count1"]) + 1).ToString();
        }
           
        obj1.Expires = DateTime.Now.AddMinutes(1);
        Response.Cookies.Add(obj1);
        lblcount.Text=obj1.Values["count1"] + " number of times user visited page";
        
    }
}
