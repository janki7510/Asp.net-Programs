﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Insert : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\Asp Programs\Unit4\Pro9\App_Data\Emp.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
       
        /*SqlCommand cmd = new SqlCommand("select max(emp_code) from Employee", con);
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            string eno = dr["emp_code"].ToString();
            if (eno == null)
            {
                TextBox1.Text = "E001";
            }
            else
            {
                TextBox2.Text = "E00" + (Convert.ToInt32(eno.Substring(1)) + 1);

            }
        }*/
    }
    
    protected void Button1_Click1(object sender, EventArgs e)
    {
        string a1, a2, M;
        Int16 a3 = 2;
        con.Open();
        cmd = new SqlCommand("select max(emp_code) from Employee", con);
        cmd.ExecuteScalar();
        a1 = cmd.ExecuteScalar().ToString();
        if (a1 == "")
        {
            a2 = "E001";
        }
        else
        {
            a2 = a1.Substring(0, 1);
            a3 = Convert.ToInt16(a1.Substring(1));
            a3 += 1;
            M = a3.ToString("D3").ToString();
            a2 += M;
            //TextBox1.Text = a2;
        }
        cmd = new SqlCommand("insert into Employee values('" + a2 + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + DropDownList1.SelectedValue + "','" + DropDownList2.SelectedValue + "','" + DropDownList3.SelectedValue + "')", con);
        Response.Write("Data Inserted Successfully");
        cmd.ExecuteNonQuery();
        con.Close();
    }
}
