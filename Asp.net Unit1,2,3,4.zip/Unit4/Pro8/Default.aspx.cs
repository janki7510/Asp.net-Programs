﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page 
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\Asp Programs\Unit4\Pro8\App_Data\Stu.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable data = new DataTable();
    int pos;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand("insert into Student values('"+TextBox1.Text+"','"+TextBox2.Text+"','"+TextBox3.Text+"')",con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("Record Inserted");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand("update Student set stuname='"+TextBox2.Text+"',marks='"+TextBox3.Text+"' where stuid='"+TextBox1.Text+"' ",con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("Record Updated");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand("delete from Student where stuid='"+TextBox1.Text+"'",con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("Record Deleted");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox1.Text = GridView1.SelectedRow.Cells[1].Text;
        TextBox2.Text = GridView1.SelectedRow.Cells[2].Text;
        TextBox3.Text = GridView1.SelectedRow.Cells[3].Text;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        da = new SqlDataAdapter("select * from Student", con);
        da.Fill(data);
        pos = 0;
        displaytext(pos);
    }
    public void displaytext(int rowno)
    {
        TextBox1.Text = data.Rows[rowno][0].ToString();
        TextBox2.Text = data.Rows[rowno][1].ToString();
        TextBox3.Text = data.Rows[rowno][2].ToString();
    }
}
