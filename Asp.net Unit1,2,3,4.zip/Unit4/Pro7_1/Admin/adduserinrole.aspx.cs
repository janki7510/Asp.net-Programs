﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_adduserinrole : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //Populate DropUser and DropRoles with users and roles
            DropUsers.DataSource = Membership.GetAllUsers();
            DropUsers.DataBind();

            DropRole.DataSource = Roles.GetAllRoles();
            DropRole.DataBind();

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string username = DropUsers.SelectedValue;
        string rolename = DropRole.SelectedValue;

        Roles.AddUserToRole(username,rolename);
        Response.Write("Role assigned!");
       
    }
}
