﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        MembershipCreateStatus CreateStatus;
        Membership.CreateUser(TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, TextBox5.Text, true, out CreateStatus);
        switch (CreateStatus)
        {
            case MembershipCreateStatus.Success:
                Label1.Text = "Congratulations! your account is successfully created.";
                Response.Redirect("Login.aspx");
                break;
            case MembershipCreateStatus.DuplicateUserName:
                Label1.Text="user name exists, please enter another name";
                break;
            default:
                Label1.Text="Your account is not created , due to unknown error!";
                break;
        }
    }
}
