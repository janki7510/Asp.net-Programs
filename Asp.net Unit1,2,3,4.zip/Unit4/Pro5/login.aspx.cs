﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class login : System.Web.UI.Page
{
    /*SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\Asp Programs\Unit4\Pro5\App_Data\Prod.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd;
    SqlDataAdapter da;*/
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        
        /*cmd = new SqlCommand("select * from Login where username='"+Login1.UserName+"'and userpass='"+Login1.Password+"'",con);
        da = new SqlDataAdapter(cmd);
        DataSet data = new DataSet();
        da.Fill(data);
        if (data.Tables[0].Rows.Count > 0)
        {
            if (data.Tables[0].Rows[0][3].ToString() == "Admin")
            {
                Response.Redirect("Product.aspx");
            }
            else
            {
                Response.Redirect("sorry.aspx");
            }
        }
        else
        {
            Response.Redirect("sorry.aspx");
        }
        */
    }
}
