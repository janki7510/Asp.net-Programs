﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Product : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\Asp Programs\Unit4\Pro5\App_Data\Prod.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd;
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd=new SqlCommand("insert into Product values('"+TextBox1.Text+"','"+TextBox2.Text+"','"+TextBox3.Text+"','"+TextBox4.Text+"','"+DropDownList1.SelectedItem+"','"+FileUpload1.FileName+"')",con);
        cmd.ExecuteNonQuery();
        Response.Write("Data Inserted Successfully");
        con.Close();

        if(FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath("~\\Images\\"+FileUpload1.FileName));
        }
        else
        {
            Response.Write("File not found");
        }
    }
}
